#include <iostream>
#include <forward_list>

using namespace std;
/*
    Remove the nth node
    Insert a given object right after the nth node
    Append on list to another (destructively)
    Make a copy of a list
    Reverse a list
*/

/* quick print function */
void print(forward_list<int> x) {
	cout << "Linked List contains: ";
	for (auto it = x.begin(); it != x.end(); ++it) {
		cout << ' ' << *it;
	}
	cout << endl;
}

int main() {
	// create the list
	forward_list<int> myList = { 16, 25, 33, 31, 55, 3 };

	// print the list
	print(myList);

/* 
remove nth node 
*/
	int n = 2; // test i value
	auto it = myList.begin(); // set iterator at beginning of list

	if (n == 0) {
		myList.pop_front(); //deletes front of list
	}
	else {
		// n-1 solves the "erase_after" quirk of this erase method
		for (int j = 0; j < n-1; j++) { 
			it++;
		}
		it = myList.erase_after(it);
	}
	cout << "--Remove nth node--\n";
	print(myList);

/* 
insert after nth node
*/
	int insert = 334;
	// reset the nth position and iterator
	n = 3; 
	it = myList.begin(); 

	for (int j = 0; j < n; j++){
		it++;
	}
	it = myList.insert_after(it, insert);
	
	cout << "--insert after nth (3) node--\n";
	print(myList);

/* 
Append on list to another(destructively) 
*/
	forward_list<int> myOtherList = { 100, 200, 300, 400 };

	it = myList.before_begin();
	myList.splice_after(it, myOtherList);
	
	//destroy the old linkedlist
	myOtherList.~forward_list();
	
	cout << "--append list--\n";
	print(myList);

/*
make a copy of a list
*/
	forward_list<int> myCopiedList = myList;
	cout << "--copy of a list--\n";
	print(myCopiedList);

/*
Reverse a list
*/
	myList.reverse();
	cout << "--reverse a list--\n";
	print(myList);

	system("PAUSE");
	return 0;

}